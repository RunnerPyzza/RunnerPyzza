RunnerPyzza
===========

An easy to use queue system for laboratory networks
---------------------------------------------------

The readme is still under construction, hang tight!

Installation
------------

python setup.py sdist
sudo pip dist/RunnerPyzza-X.tar.gz install
sudo RPadduser
sudo RPaddservice (if you are installing the server)
