#!/bin/bash
# Start the ssh-agent for the user runnerpyzza
eval $(ssh-agent)
