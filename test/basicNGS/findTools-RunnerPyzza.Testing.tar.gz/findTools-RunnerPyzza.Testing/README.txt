=========
findTools
=========

You can find a full documentation  and installation guide in .docs/index.html 
inside this tar.gz!

findTools provides such an such and so ando so. You maight find it so useful 
for task involving Next Generation Sequencing.

Enjoy! 



findTools module
----------------

findTools is also a set of library that you can also use for your scripts.
Probably the most usefull and well tested (hopefully!! :)) are:

* **libfindTools_GFF** [for gff and gtf iteration]
* **libfindTools_FASTX** [for fasta & fastq iteration]

An extensive Help should be provided... The most important feature are:

* GFF3 iteration::

    from findtools import libfindTools_GFF
    for mRNA in libfindTools_GFF.gff_itr("file/path/"):
        print mRNA.start, mRNA.end, mRNA.exons #.CDSs .UTRs ...
    
* GTF iteration::

    from findtools import libfindTools_GFF
    for transcript in libfindTools_GFF.gtf_itr("file/path/"):
        print transcript.start, transcript.end, mRNA.exons #.CDSs

* FASTA iteration::

    from findtools import libfindTools_FASTX
    for seq in libfindTools_FASTX.fasta_itr("path/to"):
        seq.header, seq.sequence, seq.sequence_mask, seq.lenght
    
* FASTQ iteration::
    
    from findtools import libfindTools_FASTX
    for seq in libfindTools_FASTX.fastq_itr("path/to"):
        print seq.header, seq.sequence, seq.quality, seq.offset

        # Quality Trim
        seq.qualityTrim(min,offset)
        print seq.sequence[seq.start, seq.end] 
        '''clean seq, start end are te trimming 
        position after qualityTrim'''

        # Adaptor Trim
        seq.leftTrimAdaptor(FastaRecord,ALLOWproportionOFmismatch)
        seq.rightTrimAdaptor(FastaRecord,ALLOWproportionOFmismatch)
        '''
        FastaRecord = seq object from fasta_itr; 
        ALLOWproportionOFmismatch = from 0.0 (FALSE) to 0.5 (50% mismatch)'''
        print seq.sequence[seq.start, seq.end] 
        '''
        clean seq, start end are te trimming position after adaptorTrim
        '''
            

findTools scripts
-----------------

findTools provide some script that you can find in your path after the installation 
(findXX -h for HELP!):

* **findASpsb** [Splice site statistics and alternative inference]
* findASisama [AS full path recostruction]
* findCLEAN [Bam file filtering such as Number of Hits or Mismatch] 
* findCOUNT [Count number of reads in a BAM for each Gene Prediction in a GFF3] 
* findSTAT [Multiple statistics in a BAM for each Gene Prediction in a GFF3]
* findEXTRACT [gtf2fasta (ALFA)]
* findDEG [Merge cvs file with GP lenght for NOISeq table (ALFA)]



I'm looking for developers and mantainers!!
-------------------------------------------
Are you interested???
    



