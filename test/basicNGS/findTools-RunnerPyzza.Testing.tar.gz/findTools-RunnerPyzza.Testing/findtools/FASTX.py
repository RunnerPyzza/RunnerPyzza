#!/usr/bin/env python

# findTools #####################################################################
#
# Author: Emilio Potenza 2011 (thanks to Marco Galardini)
# GMPF project: Emilio Potenza 2010-2013
#
# Library: FASTQ and FASTX iteration
#
#################################################################################
#
###############################################################################
# Imports
###############################################################################

import sys
import logging
logger = logging.getLogger('findtools.FASTX')


###############################################################################
# Definition
###############################################################################
def read_fasta(fname):
    '''Reads a fasta file containing one or more DNA sequences'''
    lines = open(fname, "r").readlines()
    Dseq = {}
    name = ''
    seq = ''
    for line in lines:
        if line[0] == '>':
            if name != '':
                Dseq[name] = seq
                seq = ''
            name = line[1:].strip()
        else:
            seq = seq + ''.join(line.split())
            Dseq[name] = seq
    return Dseq


def complement(s):
    """Return the complementary sequence string."""
    basecomplement = {'A': 'T', 'C': 'G', 'G': 'C', 'T': 'A',"N":"N",'a': 't', 'c': 'g', 'g': 'c', 't': 'a',"n":"n"}
    letters = list(s)
    letters = [basecomplement[base] for base in letters]
    return ''.join(letters)

def reversecomplement(s):
    """Return the reverse complement of the dna string."""
    s = s[::-1]
    s = complement(s)
    return s



'''def get_sequence(src,name):
    "Return the record in src with the given name."
    return fasta_itr(src)[name]'''


###############################################################################
# FASTA iteration
###############################################################################

class fasta_itr():
    "An iterator through a sequence of fasta records."
    def __init__(self,src):
        "Create an iterator through the records in src."
        self.__itr = _fasta_itr(src)

    def __iter__(self):
        return self
    
    def next(self):
        return self.__itr.next()

    def __getitem__(self,name):
        return _fasta_get_by_name(iter(self),name)
    
class fasta_iter_slice():
    """Provide an iteration through the fasta records in file `src', from
    index `start' to index `stop'.

    Here `src' can be either a file object or the name of a file.
    """
    def __init__(self, src, start, stop):
        """Provide an iteration through the fasta records in file `src', from
        index `start' to index `stop'.

        Here `src' can be either a file object or the name of a file.
        """
        self.__itr = _fasta_itr(src)
        self.__current = 0
        self.__start = start
        self.__stop = stop

    def __iter__(self):
        return self

    def next(self):
        while self.__current < self.__start:
            # skip past first records until we get to `start'
            self.__itr.next()
            self.__current += 1

        if self.__current >= self.__stop:
            # stop after `stop'
            raise StopIteration

        self.__current += 1
        return self.__itr.next()

    def __getitem__(self,name):
        return _fasta_get_by_name(iter(self),name)
    
class MalformedInput():
    "Exception raised when the input file does not look like a fasta file."
    pass

class FastaRecord():
    "Wrapper around a fasta record."
    def __init__(self, header, sequence):
        "Create a record with the given header and sequence."
        self.header = header
        self.sequence = sequence.upper()
        self.sequence_mask = sequence #.upper()
        self.lenght=len(sequence)

    def __str__(self):
        result = ['>'+self.header]
        for i in xrange(0,len(self.sequence),60):
            result.append(self.sequence[i:i+60])
        return '\n'.join(result)
    
    def printStd(self):
        print '>'+self.header
        for i in xrange(0,len(self.sequence),60):
            print self.sequence[i:i+60]
            
    def replacebp(self,n,bp):
        self.sequence=self.sequence[:n]+bp+self.sequence[n+1:]

def _fasta_get_by_name(itr,name):
    "Return the record in itr with the given name."
    x = name.strip()
    for rec in itr:
        if rec.header.strip() == x:
            return rec
    return None

def _fasta_itr_from_file(file):
    "Provide an iteration through the fasta records in file."

    h = file.readline().strip()
    if h[0] != '>':
        raise MalformedInput()
    h = h[1:]
    seq = []
    for line in file:
        line = line.strip() # remove newline
        if line[0] == '>':
            yield FastaRecord(h,''.join(seq))
            h = line[1:]
            seq = []
            continue
        seq += [line]
    yield FastaRecord(h,''.join(seq))

def _fasta_itr_from_name(fname):
    "Provide an iteration through the fasta records in the file named fname. "
    f = open(fname)
    for rec in _fasta_itr_from_file(f):
        yield rec
    f.close()
    
def _fasta_itr(src):
    """Provide an iteration through the fasta records in file `src'.

    Here `src' can be either a file object or the name of a file.
    """
    if type(src) == str:
        return _fasta_itr_from_name(src)
    elif type(src) == file:
        return _fasta_itr_from_file(src)
    else:
        raise TypeError


###############################################################################
# FASTQ iteration
###############################################################################

class fastq_itr():
    "An iterator through a sequence of fasta records."
    def __init__(self,src):
        "Create an iterator through the records in src."
        self.__itr = _fastq_itr(src)

    def __iter__(self):
        return self
    
    def next(self):
        return self.__itr.next()

    def __getitem__(self,name):
        return _fastq_get_by_name(iter(self),name)
    
class FastqRecord():
    "Wrapper around a fastq record."
    def __init__(self, header, sequence,quality):
        "Create a record with the given header and sequence."
        self.header = header
        self.sequence = sequence.upper()
        self.quality = quality
        self.lenght=len(sequence)
        self.start=0
        self.end=len(sequence)
        self.offset=64

    def qualityTrim(self,min,offset):
        min=int(min)
        self.offset=int(offset)
        #
        if self.start<self.end:
            for qual_pos,qual_base in enumerate(self.quality[self.start:self.end]):
                qual=ord(qual_base)- self.offset
                #print qual_base,ord(qual_base)- self.offset
                if qual<0 or qual>41:
                    sys.stderr.write("Quality offset error ==> %s : %s \n"%(qual_base,ord(qual_base)- self.offset))
                    sys.exit()
                else:
                    if qual < min:
                        self.start+=1
                    else:
                        break
        else:
            return
        if self.start<self.end:
            for qual_pos in range(len(self.quality[self.start:self.end])-1,-1,-1):
                qual_base=self.quality[qual_pos+self.start]
                qual=ord(qual_base)- self.offset
                if qual<0 or qual>41:
                    sys.stderr.write("Quality offset error ==> %s : %s \n"%(qual_base,ord(qual_base)- self.offset))
                    sys.exit()
                else:
                    if qual < min:
                        self.end=self.end-1
                    else:
                        break
        else:
            return
        return

    def equal(self,seq1,seq2,maxmismatch):
        #print seq1,seq2
        if len(seq1)!=len(seq2):
            return False
            #from sys import exit
            #exit()
        if len(seq1)<=5:
            return False
        mismatch=0.
        for n,base in enumerate(seq1):
            if base!=seq2[n]:
                mismatch+=1.
        if mismatch/len(seq1)<=maxmismatch:
            #print seq1,seq2,mismatch/len(seq1),maxmismatch, self.start, self.end
            return True
        else:
            return False



    def leftTrimAdaptor(self,FastaRec,propMismatch):
        propMismatch=float(propMismatch)
        doTrim=False
        #print FastaRec.header
        if self.start<self.end:
            for step in range(FastaRec.lenght):
                stop=self.start+(FastaRec.lenght-step)
                if stop<=self.start:
                    break
                if stop<self.lenght:
                    #print self.sequence[self.start:stop], "==", FastaRec.sequence[step:]
                    if self.equal(self.sequence[self.start:stop],FastaRec.sequence[step:],propMismatch):
                        self.start=stop
                        #print self.start, self.end
                        doTrim=True
                        break
                    else:
                        pass
                else:
                    pass
        else:
            pass
        return doTrim

    def rightTrimAdaptor(self,FastaRec,propMismatch):
        doTrim=False
        propMismatch=float(propMismatch)
        #print FastaRec.header
        if self.start<self.end:
            for step in range(FastaRec.lenght):
                start=self.end-FastaRec.lenght+step
                if start>=self.end:
                    break
                #print self.sequence[start+step:self.end], "==", FastaRec.sequence[:FastaRec.lenght-step]
                #print start,step
                if self.equal(self.sequence[start:self.end],FastaRec.sequence[:FastaRec.lenght-step],propMismatch):
                    #print self.end,FastaRec.lenght,step
                    self.end=self.end-(FastaRec.lenght-step)
                    #print self.start, self.end
                    doTrim=True
                    break
                else:
                    pass
        else:
            pass
        return doTrim

    def __str__(self):
        result = ['@'+self.header]
        result.append(self.sequence)
        result.append("+") #+self.header)
        result.append(self.quality)
        return '\n'.join(result)
    
    def printStd(self):
        print '@'+self.header
        print self.sequence
        print "+" #+self.header
        print self.quality
        
    def printStd_trim(self):
        print '@'+self.header
        print self.sequence[self.start:self.end]
        print "+" #+self.header
        print self.quality[self.start:self.end]
        
    def printStd_trim_minlen(self,min):
        min=int(min)
        #print self.start, self.end,min
        if self.end-self.start>=min:
            print '@'+self.header
            print self.sequence[self.start:self.end]
            print "+" #+self.header
            print self.quality[self.start:self.end]


def _fastq_itr_from_file(handle):
    #We need to call handle.readline() at least four times per record,
    #so we'll save a property look up each time:
    handle_readline = handle.readline

    #Skip any text before the first record (e.g. blank lines, comments?)
    while True:
       line = handle_readline()
       if line == "" : return #Premature end of file, or just empty?
       if line[0] == "@":
           break

    while True:
       if line[0] != "@":
           raise ValueError("Records in Fastq files should start with '@' character")
       title_line = line[1:].rstrip()
       #Will now be at least one line of quality data - in most FASTQ files
       #just one line! We therefore use string concatenation (if needed)
       #rather using than the "".join(...) trick just in case it is multiline:
       seq_string = handle_readline().rstrip()
       #There may now be more sequence lines, or the "+" quality marker line:
       while True:
           line = handle_readline()
           if not line:
               raise ValueError("End of file without quality information.")
           if line[0] == "+":
               #The title here is optional, but if present must match!
               second_title = line[1:].rstrip()
               if second_title and second_title != title_line:
                   raise ValueError("Sequence and quality captions differ.")
               break
           seq_string += line.rstrip() #removes trailing newlines
       #This is going to slow things down a little, but assuming
       #this isn't allowed we should try and catch it here:
       if " " in seq_string or "\t" in seq_string:
           raise ValueError("Whitespace is not allowed in the sequence.")
       seq_len = len(seq_string)

       #Will now be at least one line of quality data...
       quality_string = handle_readline().rstrip()
       #There may now be more quality data, or another sequence, or EOF
       while True:
           line = handle_readline()
           if not line : break #end of file
           if line[0] == "@":
               #This COULD be the start of a new sequence. However, it MAY just
               #be a line of quality data which starts with a "@" character.  We
               #should be able to check this by looking at the sequence length
               #and the amount of quality data found so far.
               if len(quality_string) >= seq_len:
                   #We expect it to be equal if this is the start of a new record.
                   #If the quality data is longer, we'll raise an error below.
                   break
               #Continue - its just some (more) quality data.
           quality_string += line.rstrip()

       if seq_len != len(quality_string):
           raise ValueError("Lengths of sequence and quality values differs for %s (%i and %i)." % (title_line, seq_len, len(quality_string)))

       #Return the record and then continue...
       yield FastqRecord(title_line, seq_string, quality_string)
       if not line : return #StopIteration at end of file
    assert False, "Should not reach this line"


def _fastq_itr_from_name(fname):
    "Provide an iteration through the fasta records in the file named fname. "
    f = open(fname)
    for rec in _fastq_itr_from_file(f):
        yield rec
    f.close()


def _fastq_itr(src):
    """Provide an iteration through the fastq records in file `src'.

    Here `src' can be either a file object or the name of a file.
    """
    if type(src) == str:
        return _fastq_itr_from_name(src)
    elif type(src) == file:
        return _fastq_itr_from_file(src)
    else:
        raise TypeError


def _fastq_get_by_name(itr,name):
    "Return the record in itr with the given name."
    x = name.strip()
    for rec in itr:
        if rec.header.strip() == x:
            return rec
    return None

def main():
    print "[Module] findtools.FASTX"

if __name__ == '__main__':
    main()
