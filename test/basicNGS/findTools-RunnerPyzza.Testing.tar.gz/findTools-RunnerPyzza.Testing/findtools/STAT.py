#!/usr/bin/env python

# findTools #####################################################################
#
# Author: Emilio Potenza 
# GMPF project: Emilio Potenza 2010-2013
#
# Library: Some Statistics function
#
#################################################################################
#
###############################################################################
# Imports
###############################################################################

import pysam
import logging
from commands import getoutput
from math import fmod, sqrt
from multiprocessing import Process
#from multiprocessing import Queue
from multiprocessing import Value
#from multiprocessing import cpu_count
#from multiprocessing import Lock

from findtools.LOG import ProgressBar
from findtools.LOG import barPrint

from findtools.GFF import gff_itr
#from findtools.GFF import gtf_itr

from findtools.FASTX import fasta_itr
#from findtools.FASTX import fastq_itr



logger = logging.getLogger('findtools.LOG')

###############################################################################
# Definition and Decorator
###############################################################################


def overlap(a, b):
    '''overlap corrispende al numero di basi che si sovrappongono tra
    due segmenti a=(x,y) e b=(x,y) '''
    x = min((a[1], b[1]))
    y = max((a[0], b[0]))
    overlap = x - y
    return overlap

def is_overlap(a, b):
    '''overlap corrispende al numero di basi che si sovrappongono tra
    due segmenti a=(x,y) e b=(x,y) '''
    x = min((a[1], b[1]))
    y = max((a[0], b[0]))
    overlap = x - y
    if overlap >= 0:
        return True
    else:
        return False



def spliceStatistics(statdiz):
    spliced = 0
    samfile = pysam.Samfile(input_bam, "rb")
    for AlgnRead in samfile.fetch():
        for i in AlgnRead.cigar:
            if i[0] == 2 or i[0] == 3:
                if i[1] > 25:  #min intron length= 25
                    spliced += 1
                    break
    #print AlgnRead.cigar, spliced
    statdiz["Numer of spliced alignment"] = spliced
    print "Numer of spliced alignment = ", spliced
    samfile.close()



def singleCOUNT(locallog, input_bam, gff, nohup):
    ''' Algnm count over gene '''
    print_log(locallog, "Load GFF ...")
    count_diz = {}
    contig_genes = {}
    mRNAcount = 0
    ## load gene ##
    for gene in gff_itr_gene(gff):
        count_diz[gene] = 0
        try:
            contig_genes[gene.contig].append(gene)
        except:
            contig_genes[gene.contig] = [gene]
        mRNAcount += 1
    ## Sort gene for start ##
    for contig in contig_genes:
        contig_genes[contig] = sorted(contig_genes[contig], key=lambda gene_Record: gene_Record.start)
    ## Count
    print_log(locallog, "Start ...")
    prog = ProgressBar(0, len(contig_genes), 69, mode='fixed', char='*')
    barPrint(prog, nohup, 0)
    samfile = pysam.Samfile(input_bam, "rb")
    for contig in contig_genes:
        index_contig = 0
        for AlgnRead in samfile.fetch(contig):
            start = int(AlgnRead.pos)
            end = int(AlgnRead.aend)
            for gene in contig_genes[contig][index_contig:]:
                if gene.end < start:
                    index_contig += 1
                elif is_overlap((start, end), (gene.start, gene.end)):
                    count_diz[gene] += 1
        barPrint(prog, nohup)
    barPrint(prog, nohup)
    samfile.close()
    print_log(locallog, "End ...  [")
    #for g in count_diz:
    #    if count_diz[g] != 0:
    #        print g.id, g.contig, g.end, count_diz[g]
    return count_diz



def mergeCOUNTtable(locallog, input_CSVs, nohup):
    ''' Merge csv file in findCount format '''
    if len(input_CSVs) < 2:
        findToolsExit(locallog, __findTools__, __version__, "mergeCOUNTtable", "Less than 1 csv to merge")
    merge_diz = {}
    for input_csv in input_CSVs:
        with open(input_csv, "r") as f:
            for line in f:
                line = line.split("\t")
                if line[0] not in ["V1", "V2", "V3"]:
                    merge_diz[line[0]] = []
    for input_csv in input_CSVs:
        print_log(locallog, input_csv)
        lista = merge_diz.keys()
        with open(input_csv, "r") as f:
            for line in f:
                line = line.split("\t")
                if line[0] not in ["V1", "V2", "V3"]:
                    merge_diz[line[0]].append(float(line[1]))
                    lista.remove(line[0])
            for l in lista:
                merge_diz[l].append(0.0)
    return merge_diz



def printCOUTtable(merge_diz, input_CSVs, IDs, outputName):
    '''
    Print a tabular file;
    merge_diz => id: list;
    IDs => id1,id2,id3
    '''

    def inferid(input_CSVs):
        str_infer = '#GENE\t'
        input_CSVs_words = []
        input_CSVs_words_words_set = []
        for input_csv in input_CSVs:
            words = set()
            input_csv = input_csv.replace("/", "|")
            input_csv = input_csv.replace("_", "|")
            input_csv = input_csv.replace(".", "|")
            input_csv = input_csv.split("|")
            input_CSVs_words.append(input_csv)
            for w in input_csv:
                words.add(w)
            input_CSVs_words_words_set.append(words)
        input_CSVs_words_words_intersection = input_CSVs_words_words_set[0]
        for words in input_CSVs_words_words_set[1:]:
                input_CSVs_words_words_intersection = input_CSVs_words_words_intersection & words
        for input_csv in input_CSVs_words:
            for w in input_csv:
                if w not in input_CSVs_words_words_intersection:
                    str_infer = str_infer + "_" + w
            str_infer = str_infer + "\t"
        str_infer = str_infer + "\n"
        return str_infer
    with open(outputName, "w") as f:
        if IDs:
            f.write(inferid(input_CSVs))
            f.write("#GENE\t")
            f.write("\t".join(IDs.split(",")))
            f.write("\n")
        else:
            f.write(inferid(input_CSVs))
        for gene in sorted(merge_diz):
            f.write(gene)
            for value in merge_diz[gene]:
                f.write("\t%s"%(value))
            f.write("\n")


def seqLen_in_fasta(seqlen, outputName):
    '''
    Write a tab file with Seq Name + Seq lenght in fasta file
    '''
    with open(outputName, "w") as f:
        f.write("GeneID\tLength\n")
        for read in fasta_itr(seqlen):
            f.write(read.header + "\t" + str(read.lenght) + "\n")
    return


def gffStatistics_dep(input_bam, gff, nohup):
    '''
    Deprecated
    '''
    logger.info("GFF Statistics: Start ...")
    logger.info("Load reference gene predictions")
    statList = []
    mRNAcount = 0
    exoncount = 0
    mRNAoverlap = 0
    EXONoverlap = 0
    CDSoverlap = 0
    nReads = 0
    nReadsInter = 0
    for mRNA in gff_itr(gff):
        mRNAcount += 1
        exoncount += len(mRNA.exons)
        
    prog = ProgressBar(0, mRNAcount, 90, mode='fixed', char='*')
    samfile = pysam.Samfile(input_bam, "rb")
    for mRNA in gff_itr(gff):
        x = int(mRNA.start)
        y = int(mRNA. end)
        b = (x, y)
        try:
            for AlgnRead in samfile.fetch(mRNA.contig, x, y + 1):
                nReads += 1
                intergenic = True
                nReads += 1
                start = int(AlgnRead.pos)
                end = int(AlgnRead.aend)
                a = (start, end)
                #mRNAoverlap+=1
                if is_overlap(a, b):
                    mRNAoverlap += 1
                    intergenic = False
                if intergenic:
                    nReadsInter += 1
                for exon in mRNA.exons:
                    x = int(exon[0])
                    y = int(exon[1])
                    b = (x, y)
                    if is_overlap(a, b):
                        EXONoverlap += 1
                        break
                    else:
                        pass
                for cds in mRNA.CDSs:
                    x = int(cds[0])
                    y = int(cds[1])
                    b = (x, y)
                    if is_overlap(a, b):
                        CDSoverlap += 1
                        break
                    else:
                        pass
        except ValueError as e:
            for errore in [e, mRNA.contig, mRNA.id, mRNA.start, mRNA.end, mRNA.strand, mRNA.exons, mRNA.CDSs]:
                logger.error(errore)
        barPrint(prog, nohup)
    samfile.close()
    
    logger.info("GFF Statistics: Done! [")
    logger.info("GFF Statistics Result:")
    titles = ["Number of alignments in screaned contigs:", "Number of mRNAs:", "Number of alignments overlapping mRNA:", "Number of exons:", "Number of alignments overlapping exon:", "Number of alignments overlapping CDS:", "Number of intergenics alignments:"]
    variables = [nReads, mRNAcount, mRNAoverlap, exoncount, EXONoverlap, CDSoverlap, nReadsInter]
    for title, variable in zip(titles, variables):
        logger.info(title + ":\t%s"%(variable))
        statList.append(title + ":\t%s"%(variable))
    return statList


def bamStatistics(input_bam, gff, genome, distrOUT, nohup):
    from findtools.AS import ReadWrap
    from findtools.FASTX import fasta_itr, reversecomplement, complement
    
    class Group():
        def __init__(self, id, GSeq):
            self.id = id
            self.totRead = 0
            self.NH1 = 0; self.NH2 = 0; self.NHm = 0
            self.NM0 = 0; self.NM1 = 0; self.NMm = 0
            self.nSpliceNEW = 0; self.nSpliceOLD = 0
            self.spliceLenNEW = [0 for x in range(61)] 
            self.spliceLenOLD = [0 for x in range(61)] 
            self.nSpliceUTR = 0 
            self.nSpliceCDS = 0
            self.nSpliceUtrCds = 0
            self.nSpliceEXTRA = 0
            self.insideGP = 0
            self.outsideGP = 0
            self.JunctionDict = {("GT","AG"):0, ("GC","AG"):0, ("AT","AC"):0, 'other':0}
            self.AlignDistr = {}
            self.AlignDistrWindow = 1000
            self.JCcontig = {}
            self.JCcontigPOS = {}
            for s in GSeq:
                self.JCcontig[s] = []
                self.JCcontigPOS[s] = 0
                self.AlignDistr[s] = [0 for x in range(GSeq[s]/self.AlignDistrWindow+1)]
            
        def update(self, AlgnRead, contigSeq, contig):
            self.totRead += 1
            
            self.AlignDistr[contig][AlgnRead.pos/self.AlignDistrWindow] += 1
            
            #if gp:
            #    self.insideGP +=1
            #else:
            #    self.outsideGP += 1
                
            NM=int(AlgnRead.opt("NM"))
            if NM==0:
                self.NM0 += 1
            elif NM==1:
                self.NM1 += 1
            else:
                self.NMm += 1
                
            NH=int(AlgnRead.opt("NH"))
            if NH==1:
                self.NH1 += 1
            elif NH==1:
                self.NH2 += 1
            else:
                self.NHm += 1
            
            read = ReadWrap(AlgnRead)
            if len(read.exons) > 1:
                for intron in read.edges:
                    tmp = False
                    for storeIntron in self.JCcontig[contig][self.JCcontigPOS[contig]:]:
                        if read.start > storeIntron[0]:
                            self.JCcontigPOS[contig] += 1
                        elif read.start > storeIntron[0]:
                            pass
                        else:
                            if storeIntron == intron:
                                tmp = True
                                break
                    if not tmp:
                        if self.JCcontig[contig] == []:
                            self.JCcontig[contig].append(intron)
                        else:
                            p = -1
                            try:
                                while intron[0] < self.JCcontig[contig][p][0]:
                                    p = p - 1
                                p = p + 1
                                if p == 0:
                                    self.JCcontig[contig].append(intron)
                                else:
                                    self.JCcontig[contig].insert(p,intron)
                            except IndexError:
                                #print p, intron, self.JCcontig[contig]
                                self.JCcontig[contig].append(intron)
                                self.JCcontig[contig] = sorted(self.JCcontig[contig])
                        intron_seq = contigSeq[intron[0]:intron[-1]-1]
                        sites_seq = (intron_seq[0:2], intron_seq[-2:])
                        if sites_seq in self.JunctionDict:
                            self.JunctionDict[sites_seq] += 1
                        else:
                            rev_sites_seq = (reversecomplement(intron_seq[-2:]), reversecomplement(intron_seq[0:2]))
                            if rev_sites_seq in self.JunctionDict:
                                self.JunctionDict[rev_sites_seq] += 1
                            else:
                                self.JunctionDict["other"] += 1
            
            return
        
        
        def updateGP(self, mRNAdict):
            #print len(self.JCcontig["chr1"])
            #print len(set(self.JCcontig["chr1"]))
            for contig in self.JCcontig:
                pos = 0
                for jc in sorted(self.JCcontig[contig]):
                    for GP in mRNAdict[contig][pos:]:
                        if GP.end < jc[0]:
                            pos +=1
                        elif jc[1] < GP.start:
                            gp = ''
                            break
                        else:
                            b = (GP.start, GP.end)
                            if is_overlap(jc, b):
                                gp = GP
                                break
                    if gp:
                        JC = gp.getJunctions()
                        l = jc[1] - jc[0]
                        if jc in JC:
                            self.nSpliceOLD += 1
                            self.spliceLenOLD[min((l/250,60))] += 1
                        else:
                            self.nSpliceNEW += 1
                            self.spliceLenNEW[min((l/250,60))] += 1
                            
                        ovUTR = is_overlap(jc, (gp.start, gp.CDSstart -1)) or is_overlap(jc, (gp.CDSend + 1, gp.end))
                        ovCDS = is_overlap(jc, (gp.CDSstart, gp.CDSend))
                        if ovUTR and ovCDS:
                            self.nSpliceUtrCds += 1
                        else:
                            if ovUTR:
                                self.nSpliceUTR += 1
                            if ovCDS:
                                self.nSpliceCDS += 1
                    else:
                        l = jc[1] - jc[0]
                        self.nSpliceNEW += 1
                        self.spliceLenNEW[min((l/250,60))] += 1
                        self.nSpliceEXTRA += 1     
            return
        def __str__(self):
            str = """
      @ @@ @@@ @@@@ @@@ @@ @ 
Read Group                  = %s
   --------------------------------
Total number of reads       = %s
    << Number Hits == 1     = %s
    << Number Hits == 2     = %s
    << Number Hits == 3+    = %s
    >> Number Mis == 0      = %s
    >> Number Mis == 1      = %s
    >> Number Mis == 2+     = %s

Total Splice JCs            = %s
    >> OLD                  = %s
    >> NEW                  = %s
    << UTR                  = %s
    << UTR-CDS              = %s
    << CDS                  = %s
    << EXTRA                = %s

JCs Sequence Dict
%s

Intron Length distribution step 100bp:
    >> NEW:
%s
    << OLD:
%s
       @ @@ @@@ @@@@ @@@ @@ @
"""%(self.id, self.totRead, self.NH1, self.NH2,self.NHm,
self.NM0, self.NM1,self.NMm, self.nSpliceNEW + self.nSpliceOLD,
self.nSpliceOLD, self.nSpliceNEW, self.nSpliceUTR, self.nSpliceUtrCds, self.nSpliceCDS,  
self.nSpliceEXTRA, self.JunctionDict, self.spliceLenNEW, self.spliceLenOLD)
            return str
        
    
    logger.info("loading Genome...")
    GDiz = {}
    GSeq = {}
    for fa in fasta_itr(genome):
        name = fa.header
        GDiz[name] = fa.sequence
        GSeq[name] = len(fa.sequence)
        
    logger.info("loading mRNA data...")
    mRNAdict = {}
    mRNAcount = 0
    for mRNA in gff_itr(gff):
        mRNAcount += 1
        if mRNA.contig in mRNAdict:
            mRNAdict[mRNA.contig].append(mRNA)
        else:
            mRNAdict[mRNA.contig] = [mRNA]
    # sort
    for x in mRNAdict:
        mRNAdict[x] = sorted(mRNAdict[x], key= lambda mRNA: mRNA.start)
    #compute
    groups = {}
    logger.info("Exploring BAM file %s ..."%(input_bam))
    samfile = pysam.Samfile(input_bam, "rb")
    totSeq = len(samfile.header["SQ"])
    printBar = 0
    prog = ProgressBar(0, 300000000, 90, mode='fixed', char='*')
    barPrint(prog,nohup,0)
    for sq in samfile.header["SQ"]:
        contig=sq["SN"]
        for AlgnRead in samfile.fetch(contig):
            printBar += 1
            if fmod(printBar,10000)==0:
                #logger.info(printBar)
                barPrint(prog,nohup,10000)
            
            rg = AlgnRead.opt("RG")
            if rg not in groups:
                groups[rg] = Group(rg, GSeq)
                    
            groups[rg].update(AlgnRead, GDiz[contig], contig)
                
        #barPrint(prog,nohup)
    samfile.close()
    barPrint(prog,nohup,10000)
    logger.info("Alignment statistics, Done! [")
    
    logger.info("GFF stat %s ..."%(gff))
    prog = ProgressBar(0, len(groups.keys()), 90, mode='fixed', char='*')
    barPrint(prog,nohup,0)
    for g in groups:
        groups[g].updateGP(mRNAdict)
        barPrint(prog,nohup)
    barPrint(prog,nohup)
    logger.info("GFF stat Done! [")
    
    for contig in GSeq:
        with open(distrOUT+"."+contig, "w") as f:
            line = '## '+contig+"\n## POS"
            for g in groups:
                line = line + " " + groups[g].id
            f.write(line+" Total\n")
            
            l = len(groups[g].AlignDistr[contig])
            for win in range(l):
                line = '' + str((win+1)*groups[g].AlignDistrWindow) + " "
                t = 0
                for g in groups:
                    val = groups[g].AlignDistr[contig][win]
                    t += val
                    line = line + str(val) + "\t"
                line = line + str(t) + "\n"
                f.write(line)
    
    printG = [str(groups[x]) for x in groups]
    return printG



#################################################################################
# MANUAL
#################################################################################


def main():
    print "[Module] findtools.STAT"

if __name__ == '__main__':
    main()