
#!/usr/bin/env python

# findTools #####################################################################
#
# Author: Emilio Potenza 2011
# GMPF project: Emilio Potenza 2010-2013
#
# Library: Filter function for a single pysam read 
#
#################################################################################
#
###############################################################################
# Imports
###############################################################################

import logging
import pysam
from math import fabs
from numpy import median, mean
from os import system

from findtools.LOG import ProgressBar
from findtools.LOG import barPrint

from findtools.GFF import gff_itr

from findtools.STAT import is_overlap
from findtools.STAT import overlap

logger = logging.getLogger('findtools.AS')

###############################################################################
# Class
###############################################################################


class Locus():
    """
    Locus Classes, cluster of overlapping reads
    ...replace Locus in ..._AS.py
    """

    def __init__(self, start, end, count):
        self.id = "LC%s"%(count)
        self.start = start
        self.end = end
        self.nReads = 0
        self.NH = []
        self.NM = []
        self.lenReads = []
        self.qLen = []
        self.nPaired = 0
        self.GP = []
        self.isChimera = False
        self.isNoGP = False
        self.level = 0  # 0 = first clustering 1 second clustering 2 third clustering
        self.oldlocus = None
    
    def __str__(self):
        #("# Contig Loc_ID Loc_Start Loc_End Loc_nReads Loc_isChimera, Loc_isNoGP, LocGPs\n")
        return "%s\t%s\t%s\t%s\t%s\t%s\t%s"%(self.id, self.start, self.end, self.nReads, self.isChimera, self.isNoGP, ",".join([x.id for x in self.GP]))
    
    def getRecord(self):
        # ("# Contig Loc_ID Loc_Start Loc_End Loc_nReads Chimera_Level LocGP\n")
        return"%s\t%s\t%s\t%s\t%s\t%s"%(self.id, self.start, self.end, self.nReads, self.level, ",".join([x.id for x in self.GP]))
    
    def setStart(self, start):
        self.start = start

    def setEnd(self, end):
        if end > self.end:
            self.end = end

    def upReads(self):
        self.nReads += 1

    def tmp(self):
        return self.id

    def upstat(self, read):
        self.upReads()
        '''
        ####decrease memory usage!
        if read.is_paired:
            self.nPaired+=1
        try:
            self.NM.append(int(read.opt("NM")))
        except:
            self.NM.append(0)
        try:
            self.NH.append(int(read.opt("NH")))
        except:
            self.NH.append(0)
        rlen=read.rlen
        if rlen==0: #if info is unavailable
            rlen=read.qlen
        self.lenReads.append(rlen)
        self.qLen.append(read.qlen)'''
    

class ReadWrap():
    def __init__(self, AlignRead):
        self.qname = AlignRead.qname
        self.start = AlignRead.pos + 1
        self.cigar = AlignRead.cigar
        self.RG = AlignRead.opt("RG")
        self.minIR = 25
        self.merge=self.minIR-1  ## in convertCigar
        self.exons = self.convertCigar(self.cigar, self.merge)
        '''
        self.exons [(x1,y1),(x2,y2)..] ..> x first base of alignment, y last base of align before gap, 
        x-1 un-aligned
        y+1 un-aligned
        '''
        self.end = self.exons[-1][-1]
        
        self.realexons = self.exons[:]
        self.mergeExon(self.merge)
        
        self.startSites, self.endSites = self.spliceSites()
        '''
        if len(self.exons) > 1:
            logger.debug("Read = %s Cigar = %s Exons = %s"%(self.qname,self.cigar,self.exons))
            logger.debug("Read = %s startSites = %s endSites = %s"%(self.qname,self.startSites,self.endSites))
        '''
        self.edges = []
        if self.exons > 1:
            for e in range(len(self.exons)-1):
                self.edges.append((self.exons[e][1], self.exons[e+1][0]))
        return
        
    def convertCigar(self,cigar,merge):
        start=self.start
        end=self.start
        exons=[]
        for i in cigar:
            if i[0]==0:
                end=start+i[1]
                exons.append((start,end-1))
                #if end != start:
                #    exons.append((start,end))
                #else:
                #    exons.append((start,end+1))
                start+=i[1]
            if i[0]==2 or i[0]==3:
                start+=i[1]
                end+=i[1]
        return exons

    def spliceSites(self):
        startSites=[]
        endSites=[]
        for exon in self.exons:
            s=exon[0]
            e=exon[1]
            if s!=self.start:
                startSites.append(s)
            if e!=self.end:
                endSites.append(e)
        return startSites,endSites

    def isStartSplice(self,x):
        if x in self.startSites:
            return True
        return False

    def isEndSplice(self,x):
        if x in self.endSites:
            return True
        return False

    def mergeExon(self,merge):
        tmp=False
        for i in range(len(self.exons)-1):
            if self.exons[i+1][0]-self.exons[i][1]<merge:
                self.exons[i+1]=(self.exons[i][0],self.exons[i+1][1])
                self.exons[i]=(0,0)
                tmp=True
        if tmp:
            c=self.exons.count((0,0))
            for j in range(c):
                self.exons.remove((0,0))
        return
    

class mRNAcvs():
    def __init__(self, mRNA, RG):
        self.mRNA = mRNA # gff object
        self.id = mRNA.id # name
        self.RG = RG # list of RG in the same order of the follow dictionary
        self.structure = mRNA.getStructure() # list of tuple with utr and cds
        self.mRNAedges = [] 
        self.mRNAstartSites = []
        self.mRNAendSites = []
        self.mRNAedges, self.mRNAstartSites, self.mRNAendSites = searchMRNAsites(mRNA, self.mRNAedges, 
                                    self.mRNAstartSites, self.mRNAendSites) #list of Gene Pred sites and edges
        
        self.SiteDON_ACC = {}
        self.SiteDON_ACC_seq = {}
        self.mRNASiteEC = {}
        self.newSiteEC = {} # list of count for each rg
        
        self.SiteEC = {} # Category
        self.mRNAEdgeEC = {}
        self.newEdgeEC = {}
        self.EdgeEC = {}
        self.mRNAIntronEC = {}
        self.newIntronEC = {}
        self.IntronEC = {}
        self.mRNAIntronAV_EC = {}
        self.newIntronAV_EC = {}
        self.IntronAV_EC = {}
        self.mRNAExonEC = {}
        self.newExonEC = {}
        self.ExonEC = {}
        
        self.locStart = -1
        self.locEnd = -1
        self.start = -1
        self.end = -1
        self.locusIDs = []
        self.locusCoor = []
        self.locusRead = []
        
        self.AD_AC = 0
        self.AD_AC_list = []
        
        self.exonSkip = 0
        self.exonSkip_list = []
        
        self.intronRet = 0
        self.intronRet_list = []
        
        self.cryptoIR = 0
        self.globGoodness = 0
        self.cdsGoodness = 0
        
        self.outputLines = []
        
    def __str__(self):
        s = '''
        ID = %s\t Loci = %s
        start-end %s %s 
        Structure = %s
        GloB Goodness = %s
        CDS = %s
        Cds Goodness = %s
        AD/AC = %s
        ES = %s
        IR = %s
        '''%(self.id, self.locusIDs, self.start, self.end, str(self.structure), self.globGoodness,
                self.mRNA.CDSs, self.cdsGoodness, self.AD_AC_list, self.exonSkip_list, self.intronRet_list)
        return s
    
    def addSite(self, lines):
        #print lines
        for line in lines:
            new = line[3]
            EC = line[4]
            evidence = [int(x) for x in line[5:-1]]
            pos = int(line[2])
            if new == "NEW":
                self.newSiteEC[pos] = evidence
            else:
                self.mRNASiteEC[pos] = evidence
            self.SiteEC[pos] = EC
        #print "site"
        #print self.globalSiteEC
        #print self.SiteEC
            
    def addEdge(self, lines):
        #print lines
        for line in lines:
            new = line[3]
            EC = line[4]
            evidence = [int(x) for x in line[5:-1]]
            pos = line[2].replace("(","")
            pos = pos.replace(")","")
            pos = pos.replace(" ","")
            pos = tuple([int(x) for x in pos.split(",")])
            if new == "NEW":
                self.newEdgeEC[pos] = evidence
            else:
                self.mRNAEdgeEC[pos] = evidence
            self.EdgeEC[pos] = EC
        #print "edge"
        #print self.globalEdgeEC
        #print self.EdgeEC
        
    def addExon(self, lines):
        #print lines
        for line in lines:
            new = line[3]
            EC = line[4]
            evidence = [int(x) for x in line[5:-1]]
            pos = line[2].replace("(","")
            pos = pos.replace(")","")
            pos = pos.replace(" ","")
            pos = tuple([int(x) for x in pos.split(",")])
            if new == "NEW":
                self.newExonEC[pos] = evidence
            else:
                self.mRNAExonEC[pos] = evidence
            self.ExonEC[pos] = EC
    
    def addIntronAV(self, lines):
        #print lines
        for line in lines:
            new = line[3]
            EC = line[4]
            evidence = [float(x) for x in line[5:-1]]
            pos = line[2].replace("(","")
            pos = pos.replace(")","")
            pos = pos.replace(" ","")
            pos = tuple([int(x) for x in pos.split(",")])
            if new == "NEW":
                self.newIntronAV_EC[pos] = evidence
            else:
                self.mRNAIntronAV_EC[pos] = evidence
            self.IntronAV_EC[pos] = EC
            
    def addIntron(self, lines):
        #print lines
        for line in lines:
            new = line[3]
            EC = line[4]
            evidence = [int(x) for x in line[5:-1]]
            pos = line[2].replace("(","")
            pos = pos.replace(")","")
            pos = pos.replace(" ","")
            pos = tuple([int(x) for x in pos.split(",")])
            if new == "NEW":
                self.newIntronEC[pos] = evidence
            else:
                self.mRNAIntronEC[pos] = evidence
            self.IntronEC[pos] = EC
        #print "intron"
        #print self.globalIntronEC
        #print self.IntronEC
    
    def addCov(self, file):
        if self.start > -1:
            self.cov = [0 for x in range(1 + max([self.locEnd, self.mRNA.end]) - min([self.locStart, self.mRNA.start]))]
            samfile = pysam.Samfile(file,"rb")
            logger.debug("%s %s %s-%s"%(self.mRNA.id, self.mRNA.contig, self.start, self.end))
            for AlgnRead in samfile.fetch(self.mRNA.contig, self.start, self.end):
                read = ReadWrap(AlgnRead)
                for exon in read.realexons:
                    for pos in range(exon[0], exon[1]):
                        if pos >= self.start and pos <= self.end:
                            try:
                                self.cov[pos - self.start] += 1
                            except:
                                logger.error(self.id)
                                logger.error(pos-self.start)
                                logger.error(pos)
                                logger.error(self.start)
                                logger.error(len(self.cov))
                                import sys
                                sys.exit()
                            
            samfile.close()
        
    def addLocus(self, lines):
        for line in lines:
            s = int(line[2])
            e = int(line[3])
            if s < self.locStart or self.locStart == -1:
                self.locStart = s
            if e > self.locEnd:
                self.locEnd = e
            self.locusIDs.append(line[1])
            self.locusCoor.append((s,e))
            self.locusRead.append(int(line[4]))
        self.start = min([self.locStart, self.mRNA.start])
        self.end = max([self.locEnd, self.mRNA.end])
    
    def addConsSeq(self, contigSeq):
        startSites = [x[1] for x in self.EdgeEC]
        endSites = [x[0] for x in self.EdgeEC]
        for s in self.SiteEC: 
            
            s_isStart = s in startSites
            s_isEnd = s in endSites
            if s_isStart:
                seq = contigSeq[s-3:s-1].upper()
                if self.mRNA.strand == "+" and seq in ["AG","AC"]:
                    self.SiteDON_ACC[s] = "Alt-3'"
                elif self.mRNA.strand == "-" and seq in ["AC","GC","AT"]:
                    self.SiteDON_ACC[s] = "Alt-5'"
                else:
                    self.SiteDON_ACC[s] = "Antisense"
                    
            elif s_isEnd:
                seq = contigSeq[s:s+2].upper()
                if self.mRNA.strand == "+" and seq in ["GT","GC","AT"]:
                    self.SiteDON_ACC[s] = "Alt-5'"
                elif self.mRNA.strand == "-" and seq in ["CT","GT"]:
                    self.SiteDON_ACC[s] = "Alt-3'"
                else:
                    self.SiteDON_ACC[s] = "Antisense"
            else:
                logger.error("addConsSeq")
                
            self.SiteDON_ACC_seq[s]=seq
            
        '''print self.mRNA.contig, self.mRNA.id, self.mRNA.start, self.mRNA.strand
        for x in self.structure:
            for s in x:
                if s != self.structure[0][0] and s != self.structure[-1][-1]:
                    print self.SiteDON_ACC[s],self.SiteDON_ACC_seq[s]
        print "newStart"
        for s in self.newSiteEC:
            if s in startSites:
                print self.SiteDON_ACC[s],self.SiteDON_ACC_seq[s]
        print "newEnd"
        for s in self.newSiteEC:
            if s in endSites:
                print self.SiteDON_ACC[s],self.SiteDON_ACC_seq[s]
        raw_input("???")'''
        
    def _AD_AC_stat(self, exclude):
        from bisect import bisect_right, bisect_left
        def find_le(a, x):
            'Find rightmost value less than or equal to x'
            i = bisect_right(a, x)
            if i:
                return a[i-1]
            raise ValueError

        def find_ge(a, x):
            'Find leftmost item greater than or equal to x'
            i = bisect_left(a, x)
            if i != len(a):
                return a[i]
            raise ValueError    
        #raw_input("?")
        newstartSites = [x[1] for x in self.newEdgeEC]
        newendSites = [x[0] for x in self.newEdgeEC]
        for s in self.newSiteEC: 
            s_isStart = s in newstartSites
            s_isEnd = s in newendSites
            if s >= self.mRNA.start  and s <= self.mRNA.end: 
                cat = self.SiteEC[s]
                if cat not in exclude:
                    #logger.info(s)            #logger.info(cat)
                    #logger.info(s_isStart)      #logger.info(s_isEnd)
                    #logger.info(self.structure)             #logger.info(newstartSites)
                    #logger.info(newendSites) 
                    true_aa = True
                    catNear = None
                    if s_isStart:
                        #logger.info("s %s"%s)
                        #intervallo
                        e_int = find_ge(sorted(self.mRNAendSites + [self.mRNA.start, self.mRNA.end]), s)
                        s_int = find_le(sorted(self.mRNAendSites + [self.mRNA.start, self.mRNA.end]), s)
                        #logger.info("int %s-%s"%(s_int,e_int))
                        for ms in sorted(self.mRNAstartSites):
                            if ms >=  s_int and ms <= e_int:
                                catNear = self.SiteEC[ms]
                                break
                    elif s_isEnd:
                        #logger.info("e %s"%s)
                        #intervallo
                        e_int = find_ge(sorted(self.mRNAstartSites + [self.mRNA.start, self.mRNA.end]), s)
                        s_int = find_le(sorted(self.mRNAstartSites + [self.mRNA.start, self.mRNA.end]), s)
                        #logger.info("int %s-%s"%(s_int,e_int))
                        for ms in sorted(self.mRNAendSites):
                            if ms >=  s_int and ms <= e_int:
                                catNear = self.SiteEC[ms]
                                break
                    else:
                        logger.error(self.mRNA.id)
                        logger.error("AD_AC_stat!!")
                    
                    #logger.info(ms)
                    #logger.info(catNear)
                    if catNear:
                        if catNear in exclude:
                            true_aa = False
                    else:
                        true_aa = False
                     
                    
                    goodEdge = False
                    #logger.info(self.newEdgeEC)
                    if true_aa:
                        for edge in self.newEdgeEC:
                            if s in edge:
                                catEdge = self.EdgeEC[edge]
                                goodEdge = catEdge not in exclude
                                if goodEdge:
                                    #logger.info("good")
                                    #goodedge = edge
                                    break
                    if not goodEdge:
                        true_aa = False
                        
                    if true_aa:
                        #logger.info("TRUE")
                        self.AD_AC += 1
                        self.AD_AC_list.append(s)
                        
                        if s_isStart:
                            end = find_ge(sorted(self.mRNAendSites + [self.mRNA.start, self.mRNA.end]), s)
                            #newExon = (s, end)
                            #consExon = (ms,end)
                        else:
                            start = find_le(sorted(self.mRNAstartSites + [self.mRNA.start, self.mRNA.end]), s)
                            #newExon = (start, s)
                            #consExon = (start, ms)
                            
                        s_evidence = self.newSiteEC[s]
                        s_rg, s_count = self.getRG_count(s_evidence)

                        c_evidence = self.mRNASiteEC[ms]
                        c_rg, c_count = self.getRG_count(c_evidence)

                        output = [self.mRNA.contig, self.mRNA.id, self.SiteDON_ACC[s], str(s), s_rg, s_count,
                            str(ms), c_rg, c_count]
                        self.outputLines.append("\t".join(output))
                        
                    
                        
    def _exonSkip_stat(self, exclude):
        for s in self.newEdgeEC:
            if s[0] not in self.newSiteEC and s[1] not in self.newSiteEC:
                real_es = True
                for site in self.mRNASiteEC:
                    if site >= s[0] and site <= s[1]:
                        EC_site = self.SiteEC[site]
                        if EC_site in exclude:
                            real_es = False
                            break
                if real_es:
                    cat = self.EdgeEC[s]
                    if cat not in exclude:
                        self.exonSkip += 1
                        self.exonSkip_list.append(s)
                        
                        s_evidence = self.newEdgeEC[s]
                        s_rg, s_count = self.getRG_count(s_evidence)
                        
                        alt1 = self.getExon(s[0], 1)
                        indx1 = self.structure.index(alt1)
                        consensus2 = self.structure[indx1 + 1]
                        
                        alt2 = self.getExon(s[1], 0)
                        indx2 = self.structure.index(alt2)
                        consensus3 = self.structure[indx2 -1]
                        
                        c1 = (alt1[1],consensus2[0])
                        c1_evidence = self.mRNAEdgeEC[c1]
                        c1_rg, c1_count = self.getRG_count(c1_evidence)
                        
                        c2 = (consensus3[1],alt2[0])
                        c2_evidence = self.mRNAEdgeEC[c2]
                        c2_rg, c2_count = self.getRG_count(c2_evidence)
                        
                        if not c1_rg:
                             c1_rg = "E"
                        if not c2_count:
                             c2_count = "0"
                        if not c2_rg:
                             c2_rg = "E"
                        if not c2_count:
                             c2_count = "0"   

                        output = [self.mRNA.contig, self.mRNA.id, "ES", "%s,%s"%(alt1,alt2), s_rg, s_count,
                            "%s,%s..%s,%s"%(alt1,consensus2,consensus3,alt2), "%s..%s"%(c1_rg,c2_rg),
                            "%s..%s"%(c1_count,c2_count)]
                        self.outputLines.append("\t".join(output))
    
    def getExon(self, site, s_e):
        for exon in self.structure:
            if exon[s_e] == site:
                return exon
        return None
    def getRG_count(self, evidence):
        rg = ''
        count = ''
        for i,j in zip(self.RG, evidence):
            if int(j) > 0:
                if rg != '':
                    rg = rg + "," + i
                    count = count + ",%s"%(j)
                else:
                    rg = i
                    count = "%s"%(j)
        return rg,count
    
    def _intronRetention_stat(self, exclude):
            
        for s in self.mRNAIntronEC:
            cat = self.IntronEC[s]
            catEdge = self.EdgeEC[s]
            if cat not in exclude and catEdge  not in exclude:
                self.intronRet += 1
                self.intronRet_list.append(s)
        
                s_evidence = self.mRNAIntronEC[s]
                s_rg, s_count = self.getRG_count(s_evidence)
                
                consensus1 = self.getExon(s[0], 1)
                consensus2 = self.getExon(s[1], 0)
                c_evidence = self.mRNAEdgeEC[s]
                c_rg, c_count = self.getRG_count(c_evidence)
                
                output = [self.mRNA.contig, self.mRNA.id, "IR", str(s), s_rg, s_count,
                    "%s,%s"%(consensus1,consensus2), c_rg, c_count]
                self.outputLines.append("\t".join(output))
                
    def _crypticIntron_stat(self, exclude):
        for s in self.newEdgeEC:
            cat_crypto = self.EdgeEC[s]
            if cat_crypto not in exclude:
                if s[0] in self.newSiteEC and s[1] in self.newSiteEC:
                    for exon in self.mRNAExonEC:
                        if s[0] > exon[0] and s[1] < exon[1]:
                            cat = self.ExonEC[exon]
                            if exon[0] != self.structure[0][0]:
                                catS = self.SiteEC[exon[0]]
                            else:
                                catS = "A" #se e' un un esone esterno salta il controllo sul bordo esterno
                            if exon[1] !=  self.structure[-1][-1]:
                                catE = self.SiteEC[exon[1]]
                            else:
                                catE = "A" #se e' un un esone esterno salta il controllo sul bordo esterno
                            if cat not in exclude and catS  not in exclude and catE not in exclude:
                                self.cryptoIR += 1
                                self.intronRet += 1
                                self.intronRet_list.append(s)
                            
                                c_evidence = self.mRNAExonEC[exon]
                                c_rg, c_count = self.getRG_count(c_evidence)

                                alt1 = (exon[0],s[0])
                                alt2 = (s[1],exon[1])
                                s_evidence = self.newEdgeEC[s]
                                s_rg, s_count = self.getRG_count(s_evidence)

                                output = [self.mRNA.contig, self.mRNA.id, "IRc", "%s,%s"%(alt1,alt2), s_rg, s_count,
                                    str(exon), c_rg, c_count]
                                self.outputLines.append("\t".join(output))
                

    def gpCov(self, percent):
        x = []
        if self.start > -1:
            len_mRNA = 0
            for exon in self.structure:
                len_mRNA += exon[1]-exon[0]
            stop = len_mRNA * percent / 100
            stop = int(round(stop, 0))
            setZero = min([self.locStart, self.mRNA.start])
            
            if self.mRNA.strand == "+":
                c = 0
                for exon in self.structure:
                    for bp in range(exon[0],exon[1]):
                        if c >= stop:
                            break
                        try:
                            cov = self.cov[bp-setZero]
                        except:
                            logger.error(bp-setZero)
                            logger.error(bp)
                            logger.error(setZero)
                            logger.error(len(self.cov))
                            import sys
                            sys.exit()
                        x.append(cov)
                        c += 1
            else:
                c = 0
                for ex in self.structure[::-1]:
                    for bp in range(ex[1]-1,ex[0]+1,-1):
                        if c >= stop:
                            break
                        try:
                            cov = self.cov[bp-setZero]
                        except:
                            logger.error(bp-setZero)
                            logger.error(bp)
                            logger.error(setZero)
                            logger.error(len(self.cov))
                            import sys
                            sys.exit()
                        x.append(cov)
                        c += 1
            #print self.id, self.cov, x, median(x)
            if x != []:
                #return median(x)
                return mean(x)
            else:
                return 0.0
        else:
            return 0.0
    
    def _goodness(self, exclude):
        n_site = 0.
        cds_site = 0.
        good_site = 0.
        cds_good_site = 0.
        for s in self.mRNAstartSites + self.mRNAendSites:
            n_site += 1
            if s >= self.mRNA.CDSstart and s <= self.mRNA.CDSend:
                cds_site += 1
            if s in self.mRNASiteEC:
                cat = self.SiteEC[s]
                if cat not in exclude:
                    good_site += 1
                    if s >= self.mRNA.CDSstart and s <= self.mRNA.CDSend:
                        cds_good_site += 1
        for edge in self.mRNAedges:
            n_site += 1
            if edge[0] >= self.mRNA.CDSstart and edge[0] <= self.mRNA.CDSend:
                cds_site += 1
            if edge in self.mRNAEdgeEC:
                cat = self.EdgeEC[edge]
                if cat not in exclude:
                    good_site += 1
                    if edge[0] >= self.mRNA.CDSstart and edge[0] <= self.mRNA.CDSend:
                        cds_good_site += 1
            
        try:
            self.globGoodness = good_site / n_site
        except:
            self.globGoodness = 0
        try:
            self.cdsGoodness = cds_good_site / cds_site
        except:
            self.cdsGoodness = 0
    
    
    def _checkFeature(self, filters, evidenceDiz, classesDiz):
        '''
        filter = ["&",">=50",(">=5"(num group),">=5"(with reads))]
        '''
        from findtools.CLEAN import filterINT

        for x in evidenceDiz:
            check = False
            for c in ["A","B","C","D"]:
                filter = filters[c]
                x_val = [int(j) for j in evidenceDiz[x]]
                x_sum = sum(x_val)
                bool_sum = filterINT(x_sum, filter[1])
                x_count = 0
                for k in x_val:
                    if filterINT(k, filter[2][1]):
                        x_count += 1
                bool_count = filterINT(x_count, filter[2][0])
                if filter[0] == "&":
                    check = bool_sum and bool_count
                else:
                    check = bool_sum or bool_count
                if check:
                    classesDiz[x] = c
                    break
            if not check:
                classesDiz[x] = "E"
                
    def _newEvidenceCheck(self,classes):
        self._checkFeature(classes, self.mRNASiteEC, self.SiteEC)
        self._checkFeature(classes, self.newSiteEC, self.SiteEC)
        self._checkFeature(classes, self.mRNAEdgeEC, self.EdgeEC)
        self._checkFeature(classes, self.newEdgeEC, self.EdgeEC)
        self._checkFeature(classes, self.mRNAIntronEC, self.IntronEC)
        self._checkFeature(classes, self.newIntronEC, self.IntronEC)
        self._checkFeature(classes, self.mRNAExonEC, self.ExonEC)
        self._checkFeature(classes, self.newExonEC, self.ExonEC)
        return
    
    def statAS(self, exclude, classes):
        
        self._newEvidenceCheck(classes)
        self._goodness(exclude)
        self._AD_AC_stat(exclude)
        self._exonSkip_stat(exclude)
        self._intronRetention_stat(exclude)
        self._crypticIntron_stat(exclude)
                
        
        
    
    
###############################################################################
# Function
###############################################################################

def grepCVSfile(file, mRNAid):
    #DEP
    check_list = []
    with open(file) as f:
        for line in f:
            line = line.strip().split("\t")
            if line[1] == mRNAid:
                check_list.append(line)
    return check_list


def grepLocusFile(file, mRNAid):
    #DEP
    check_list = []
    with open(file) as f:
        for line in f:
            line = line.strip().split("\t")
            if line[-1] == mRNAid:
                check_list.append(line)
    return check_list


def writeLocusDict(file, locusDict):
    with open(file,"w") as f:
        f.write("# Contig Loc_ID Loc_Start Loc_End Loc_nReads Loc_isChimera, Loc_isNoGP, LocGPs\n")
        for contig in locusDict:
            for locus in locusDict[contig]:
                f.write("%s\t%s\n"%(contig, locus))
    return

def writeBAMclean(options, locus_file, samtools_log, input_bam, output_clean_BAM, output_trash_BAM, 
        output_clean_sort_BAM, output_trash_sort_BAM, locusINcontig, 
        newlocusINcontig, new_newlocusINcontig, minReads):
    '''
    Write Clean and Trash BAM file
    '''
    def writeRead(contig, input_bam, bamfile, trashBAM, locus, minReads):
        '''
        if check is True --> pass filters
        else write directly in trash
        '''
        samfile = pysam.Samfile(input_bam, "rb")
        for AlgnRead in samfile.fetch(contig, locus.start, locus.end):
            check = True
            if locus.nReads <= minReads:
                check = False
            if check:
                if locus.level == 0:
                    pass
                elif locus.level == 1:
                    GPs=sorted(locus.oldlocus.GP,key=lambda mRNA_Record: mRNA_Record.start)
                    if is_chimeraRead(AlgnRead, GPs, False):
                        check = False
                elif locus.level == 2:
                    GPs=sorted(locus.oldlocus.GP,key=lambda mRNA_Record: mRNA_Record.start)
                    if is_chimeraRead(AlgnRead, GPs, True):
                        check = False
            if check:
                bamfile.write(AlgnRead)
            else:
                trashBAM.write(AlgnRead)
        samfile.close()
        
        
    logger.info("findAS: Write BAM with used reads ...")
    samfile = pysam.Samfile(input_bam, "rb")
    bamfile = pysam.Samfile(output_clean_BAM, "wb", template = samfile)
    trashBAM = pysam.Samfile(output_trash_BAM, "wb", template = samfile)
    samfile.close()
    prog = ProgressBar(0, len(locusINcontig) , 90, mode='fixed', char='*')
    with open(locus_file,"w") as f:
        f.write("")
        for contig in locusINcontig:
            loci_in_contig = locusINcontig[contig] + newlocusINcontig[contig] + new_newlocusINcontig[contig]
            loci_in_contig = sorted(loci_in_contig, key=lambda Locus: Locus.start)
            for locus in loci_in_contig:
                # write locus cvs
                if not locus.isChimera and locus.nReads > minReads and not locus.isNoGP:
                    f.write("%s\t%s\n"%(contig, locus.getRecord()))
                # write bam files
                if not locus.isChimera:
                    writeRead(contig, input_bam, bamfile, trashBAM, locus, minReads) #(locus.nReads > minReads and not locus.isNoGP))    
            barPrint(prog, options.nohup)
    bamfile.close()
    logger.info("findAS: Write BAM with used reads Done! [")
    
    cmd_sort = "%s sort %s %s >> %s 2>> %s"%(options.samtools, output_clean_BAM, output_clean_sort_BAM[:-4], samtools_log, samtools_log)
    cmd_rm_unsort = "rm -f %s >> %s 2>> %s"%(output_clean_BAM, samtools_log, samtools_log)
    cmd_index = "%s index %s >> %s 2>> %s"%(options.samtools, output_clean_sort_BAM, samtools_log, samtools_log)
    
    cmd_sort_2 = "%s sort %s %s >> %s 2>> %s"%(options.samtools, output_trash_BAM, output_trash_sort_BAM[:-4], samtools_log, samtools_log)
    cmd_rm_unsort_2 = "rm -f %s >> %s 2>> %s"%(output_trash_BAM, samtools_log, samtools_log)
    cmd_index_2 = "%s index %s >> %s 2>> %s"%(options.samtools, output_trash_sort_BAM, samtools_log, samtools_log)

    #from commands import
    logger.info("findAS: sort BAMs files, please wait ...")
    system(cmd_sort)
    system(cmd_sort_2)
    logger.info("findAS: rm unsorted BAMs files, please wait ...")
    system(cmd_rm_unsort)
    system(cmd_rm_unsort_2)
    logger.info("findAS: index BAMs files, please wait ...")
    system(cmd_index)
    system(cmd_index_2)
    
    
    '''### Tmp file ... with removed reads only during  Chimera...
    cmd_merge = "%s merge %s %s %s >> %s 2>> %s"%(options.samtools, wdir + output_core + "_unused.bam" ,wdir + output_core + "_tmpII.bam" ,wdir + output_core + "_tmpIII.bam" , 
        wdir + output_core + "_samtools.log", wdir + output_core + "_samtools.log")
    cmd_sort = "%s sort %s %s >> %s 2>> %s"%(options.samtools, wdir + output_core + "_unused.bam", 
        wdir + output_core + "_unused_sort",     wdir + output_core + "_samtools.log", wdir + output_core + "_samtools.log")
    cmd_rm_unsort = "rm -f %s >> %s 2>> %s"%(wdir + output_core + "_unused.bam", wdir + output_core + "_samtools.log",
        wdir + output_core + "_samtools.log")    
    cmd_index = "%s index %s >> %s 2>> %s"%(options.samtools, wdir + output_core + "_unused_sort.bam",
        wdir + output_core + "_samtools.log", wdir + output_core + "_samtools.log") 
    cmd_rm_tmp2 = "rm -f %s >> %s 2>> %s"%(wdir + output_core + "_tmpII.bam", wdir + output_core + "_samtools.log",
        wdir + output_core + "_samtools.log")
    cmd_rm_tmp3 = "rm -f %s >> %s 2>> %s"%(wdir + output_core + "_tmpIII.bam", wdir + output_core + "_samtools.log",
        wdir + output_core + "_samtools.log")
        
    logger.info("findAS: merge unused BAM, please wait ...")
    system(cmd_merge)
    logger.info("findAS: sort and index BAM, please wait ...")
    system(cmd_sort)
    logger.info("findAS: rm unsorted BAM, please wait ...")
    system(cmd_rm_unsort)
    system(cmd_rm_tmp2)
    system(cmd_rm_tmp3)
    logger.info("findAS: index sorted BAM, please wait ...")
    system(cmd_index)'''
    return

###############################################################################
# Chimera Search
###############################################################################

def clustering_I(options, input_bam, locusINcontig, c_id):
        samfile = pysam.Samfile(input_bam, "rb")
        total = len(samfile.header["SQ"])
        logger.info("Inspecting Loci in %s sequences ..."%(total))
        prog = ProgressBar(0, total, 90, mode='fixed', char='*')
        barPrint(prog, options.nohup,0)
        stop = 0
        for sq in samfile.header["SQ"]:
            contig=sq["SN"]
            ln=sq["LN"]
            locusINcontig[contig]=[]
            locus=''
            #for AlgnRead in samfile.fetch("chr1"):
            for AlgnRead in samfile.fetch(contig):
                #########################################
                #stop += 1
                #
                #if stop == 100000:
                #    break
                #if c_id > 10000:
                #    break
                #########################################
                if locus=='':
                    c_id+=1
                    locus=Locus(AlgnRead.pos, AlgnRead.aend, c_id)
                    locus.upstat(AlgnRead)
                else:
                    if AlgnRead.pos>locus.end:
                        c_id+=1
                        locusINcontig[contig].append(locus)
                        locus=Locus(AlgnRead.pos, AlgnRead.aend, c_id)
                        locus.upstat(AlgnRead)
                    else:
                        locus.setEnd(AlgnRead.aend)
                        locus.upstat(AlgnRead)
            if locus!='':
                locusINcontig[contig].append(locus)
            
            ######################
            #
            #break;
            ######################
            barPrint(prog, options.nohup)
        logger.info("Inspecting Loci in %s contig DONE ["%(total))
        samfile.close() 
        return locusINcontig, c_id
    
def clustering_II(options, linkname, rmBAMfile, input_bam, locusINcontig, c_id, count_chim = 0, newlocusINcontig = {}, force=False):
    '''
    II force = False
    III force = True
    '''
    samfile = pysam.Samfile(input_bam, "rb")
    bamfile = pysam.Samfile(rmBAMfile, "wb", template = samfile)
    samfile.close()
    
    logger.info("Inspecting %s Chimere ..."%(count_chim))
    prog = ProgressBar(0, count_chim, 90, mode='fixed', char='*')
    barPrint(prog, options.nohup,0)
    with open(linkname,"w") as f:
        f.write("#contig, oldlocus.id, oldlocus.start, oldlocus.end, oldlocus.nReads, n_new_locus,  str_new_locus_id, sum_new_reads, n_remov_reads\n")
        stop = 0
        
        for contig in locusINcontig:
            last_locus_end = -1
            newlocusINcontig[contig]=[]
            old_loci = locusINcontig[contig] #is sorted but...
            old_loci = sorted(old_loci,key=lambda Locus: Locus.start)
            for oldlocus in old_loci:
                if oldlocus.isChimera:
                    n_remov_reads = 0
                    n_new_locus = 0
                    str_new_locus_id = ''
                    sum_new_reads = 0
                    samfile = pysam.Samfile(input_bam, "rb")
                    locus=''
                    GPs=sorted(oldlocus.GP,key=lambda mRNA_Record: mRNA_Record.start)
                    #tmp_gps = [(t.start,t.end) for t in GPs]
                    #logger.info(oldlocus.id)
                    #logger.info(tmp_gps)
                    #intron_reg = []
                    #for pos in range(len(GPs)-1):
                    #    intron_reg.append((GPs[pos].end -1, GPs[pos +1].start +1))
                    #logger.info(intron_reg)
                    #logger.info("")
                    for AlgnRead in samfile.fetch(contig, oldlocus.start, oldlocus.end):
                        if is_overlap((AlgnRead.pos, AlgnRead.aend),(oldlocus.start, oldlocus.end)) and AlgnRead.pos > last_locus_end:
                            #########################################
                            #stop += 1
                            #
                            #if stop == 100000:
                            #    break
                            #if c_id > 20000:
                            #    break
                            #########################################
                            if is_chimeraRead(AlgnRead, GPs, force):
                                n_remov_reads += 1
                                bamfile.write(AlgnRead)
                            else:
                                if locus=='':
                                    c_id+=1
                                    n_new_locus += 1
                                    locus=Locus(AlgnRead.pos, AlgnRead.aend, c_id)
                                    locus.upstat(AlgnRead)
                                    locus.oldlocus = oldlocus
                                    locus.level = 1
                                    if force:
                                        locus.level = 2
                                    str_new_locus_id = str_new_locus_id + "%s,"%locus.id
                                else:
                                    if AlgnRead.pos>locus.end:
                                        c_id += 1
                                        n_new_locus += 1
                                        sum_new_reads += locus.nReads
                                        newlocusINcontig[contig].append(locus)
                                        last_locus_end = locus.end
                                        locus=Locus(AlgnRead.pos, AlgnRead.aend, c_id)
                                        locus.oldlocus = oldlocus
                                        locus.level = 1
                                        if force:
                                            locus.level = 2
                                        locus.upstat(AlgnRead)
                                        str_new_locus_id = str_new_locus_id + "%s,"%locus.id
                                    else:
                                        locus.setEnd(AlgnRead.aend)
                                        locus.upstat(AlgnRead)
                    if locus!='':
                        sum_new_reads += locus.nReads
                        newlocusINcontig[contig].append(locus)
                        last_locus_end = locus.end
                    samfile.close()
                    report_list = [contig, oldlocus.id, str(oldlocus.start), str(oldlocus.end), str(oldlocus.nReads), str(n_new_locus), str(str_new_locus_id), str(sum_new_reads), str(n_remov_reads)]
                    f.write(report_list[0])
                    for elm in report_list[1:]:
                        f.write("\t"+elm)
                    f.write("\n")
                    barPrint(prog, options.nohup)
    bamfile.close()
    logger.info("Inspecting %s Chimere DONE ["%(count_chim))  
    return newlocusINcontig, c_id

def is_chimeraRead(read, GPs, force):
    read = ReadWrap(read)
    start = read.start -1
    end = read.end +1
    a = (start,end)
    c_ovelap = 0
    for gp in GPs:
        b = (gp.start, gp.end)
        if is_overlap(a,b):
            c_ovelap += 1
    if c_ovelap >= 2:
        return True
    if force:
        for gp in GPs:
            if start >= gp.start and end <= gp.end: 
                #se la reads e' interna:
                return False
        return True
        '''intron_reg = []
        for pos in range(len(GPs)-1):
            intron_reg.append((GPs[pos].end - 1 , GPs[pos + 1].start + 1))
        for b in intron_reg:
            if is_overlap(a,b):
                return True'''
    return False
                
            
        
    
'''def is_chimeraRead(read, GPs, force):
    
    #Return true if read is a chimera for GPs list of mRNA
    
    start = read.pos
    end = read.aend
    if force:
        pos = 0
        #Remove all the the reads that overlap an intergenic reagion
        a = (start,end)
        for pos in range(len(GPs)-1):
            b = (GPs[pos].end-1, GPs[pos-1].start+1)
            if is_overlap(a,b):
                return True
        return False
    else:
        pos = 0
        #Remove all the reads that overlap two gene prediction
        a = (start,end)
        #intergenic_regions = [] intergenic_regions.append((GPs[pos],GPs[pos+1]))
        for pos in range(len(GPs)-1):
            b = (GPs[pos].end-1, GPs[pos-1].start+1)
            if overlap(a,b) > 0 and overlap(a,b) < b[1]-b[0]:
                return True
        return False'''

def addmRNA(gff, diz, mRNAcount):
    '''
    Add mRNA prediction in gff TO LOCUS object in diz
    diz[contig]=[locus,locus...]
    '''
    #prog = ProgressBar(0, mRNAcount, 90, mode='fixed', char='*')
    for mRNA in gff_itr(gff):
        x = int(mRNA.start)
        y = int(mRNA.end)
        b = (x, y)
        if mRNA.contig in diz:
            for locus in diz[mRNA.contig]:
                a = (int(locus.start), int(locus.end))
                if int(locus.start) > int(mRNA.end):
                    break
                if is_overlap(a, b):
                    locus.GP.append(mRNA)
                #print mRNA.contig, locus.id, int(locus.start), int(locus.end), mRNA.id, x, y
    return diz

def updateChimera(locusINcontig):
    '''
    SET locus variable isChimera or isNoGP
    '''
    count_tot = 0
    count_chim = 0
    count_nogp = 0
    for contig in locusINcontig:
        for p,locus in enumerate(locusINcontig[contig]):
            if len(locus.GP) == 0:
                count_nogp += 1
                locusINcontig[contig][p].isNoGP = True
                #logger.debug("%s-%s, %s"%(locus.start, locus.end, locus.nReads))    
            elif len(locus.GP) >= 2:
                locusINcontig[contig][p].isChimera = True
                count_chim += 1
            else:
                pass
            count_tot += 1
    logger.info("Total Loci= %s"%count_tot)
    logger.info("Loci with chimera= %s"%count_chim)
    logger.info("Loci with no GP= %s"%count_nogp)
    return locusINcontig, count_tot, count_chim



###############################################################################
# Evidence Detection
###############################################################################

def searchINdict(mRNA, minReads, locusINcontig, count_chim, newlocusINcontig, new_count_chim, new_newlocusINcontig):
    '''
    Return a list of all loci inside an mRNA
    '''
    mRNA_loci = []
    for locus in locusINcontig[mRNA.contig]:
        if locus.nReads > minReads and not locus.isNoGP and not locus.isChimera:
            list_GP_id = [x.id for x in locus.GP]
            if mRNA.id in list_GP_id:
                locus.level = 0 # set clustering level
                mRNA_loci.append(locus)
    if count_chim > 0:
        for locus in newlocusINcontig[mRNA.contig]:
            if locus.nReads > minReads and not locus.isNoGP and not locus.isChimera:
                list_GP_id = [x.id for x in locus.GP]
                if mRNA.id in list_GP_id:
                    locus.level = 1
                    mRNA_loci.append(locus)
        if new_count_chim > 0:
            for locus in new_newlocusINcontig[mRNA.contig]:
                if locus.nReads > minReads and not locus.isNoGP and not locus.isChimera:
                    list_GP_id = [x.id for x in locus.GP]
                    if mRNA.id in list_GP_id:
                        locus.level = 2
                        mRNA_loci.append(locus)
    logger.debug("mRNA = %s %s-%s--> n. clean Loci %s, %s"%(mRNA.id, mRNA.start, mRNA.end, len(mRNA_loci), [x.id for x in mRNA_loci]))
    return mRNA_loci, locusINcontig, newlocusINcontig, new_newlocusINcontig

def searchMRNAsites(mRNA, mRNAedges = [], mRNAstartSites = [], mRNAendSites= []):
    '''
    find splice site and edges inside a Gene Prediction
    IMPORTANT : GFF with CDS and UTR !!!!!
    
    starts are only a splisce site, not the start of cds not the start of UTR...
    the same for the ends
    
    mRNAedges = [] #[(exonEND, exon+1START)..]
    mRNAstartSites = [] #[exonSTART, exonSTART..]
    mRNAendSites = [] #[exonEND, exonEND..]
    '''
    struct = mRNA.getStructure()
    start = struct[0][0]
    end = struct[-1][-1]
    for exon in struct:
        s=exon[0]
        e=exon[1]
        ##HERE UPDATE STRAND DISCRIMINATION
        if s != start:
            mRNAstartSites.append(s)
        if e != end:
            mRNAendSites.append(e)
    for e in range(len(struct)-1):
        coord = tuple([struct[e][1], struct[e+1][0]])
        mRNAedges.append(coord)
    '''
    #OLD WAY
    for exon in mRNA.CDSs + mRNA.UTRs:
        s=exon[0]
        e=exon[1]
        if s != mRNA.CDSstart and s != mRNA.start and s != mRNA.CDSend + 1:
            mRNAstartSites.append(s)
        if e != mRNA.CDSend and e!= mRNA.end and s != mRNA.CDSstart - 1:
            mRNAendSites.append(e)
    if sorted(mRNA.CDSs) > 1:
        for e in range(len(mRNA.CDSs)-1):
            coord = tuple([mRNA.CDSs[e][1], mRNA.CDSs[e+1][0]])
            mRNAedges.append(coord)
    '''
    return mRNAedges, mRNAstartSites, mRNAendSites

def updateALLsitesDict(input_bam, mRNA, locus, startSites, endSites, edges):
    '''
    Update all the dictionary for Splice site recognition and edges
    
    '''
    def updateSitesDict(recordDict, sitesList, read):
        '''
        Create dictionary for start sites, end sites and edges
        with RG distribution dictionary
        '''
        for s in sitesList:
            if s in recordDict:
                try:
                    recordDict[s][read.RG] += 1
                except KeyError:
                    recordDict[s][read.RG] = 1
            else:
                recordDict[s]={read.RG:1}
        return recordDict
    
    samfile = pysam.Samfile(input_bam, "rb")
    for AlgnRead in samfile.fetch(mRNA.contig, locus.start, locus.end):
        check = True
        if check:
            
            read = ReadWrap(AlgnRead)
                    
            startSites = updateSitesDict(startSites, read.startSites, read)
            endSites = updateSitesDict(endSites, read.endSites, read)
            edges = updateSitesDict(edges, read.edges, read)
    samfile.close()
    
    return startSites, endSites, edges
  

def lociINmRNA(mRNA, minReads, locusINcontig, newlocusINcontig, new_newlocusINcontig):
    '''
    DEPRECATED: Return a list of all loci inside an mRNA
    '''
    mRNA_loci = []
    for locus in locusINcontig[mRNA.contig] + newlocusINcontig[mRNA.contig] + new_newlocusINcontig[mRNA.contig]:
        if locus.nReads > minReads and not locus.isNoGP and not locus.isChimera:
            list_GP_id = [x.id for x in locus.GP]
            if mRNA.id in list_GP_id:
                mRNA_loci.append(locus)
    logger.debug("mRNA = %s %s-%s--> n. clean Loci %s, %s"%(mRNA.id, mRNA.start, mRNA.end, len(mRNA_loci), 
    [x.id for x in mRNA_loci]))
    return mRNA_loci



def writeSTATsite(filename, mRNA, RGs, mRNAsites, DATAsitesdict):
    #stop += 1
    '''
    write cvs file with coverage and evidence check
    '''
    allStart = sorted(set(mRNAsites + DATAsitesdict.keys()))
    with open(filename,"a") as f:
        for site in allStart:
            f.write("%s\t%s\t%s\t"%(mRNA.contig, mRNA.id, site))
            if site in mRNAsites:
                f.write("mRNA\t")
            else:
                f.write("NEW\t")
            f.write(evidenceCheck(site, DATAsitesdict, RGs)+"\t")
            tot = 0
            if site in DATAsitesdict:
                for RG in RGs:
                    if RG in DATAsitesdict[site]:
                        tot += DATAsitesdict[site][RG]
                        f.write("%s\t"%DATAsitesdict[site][RG])
                    else:
                        #pass
                        f.write("0\t")
            else:
                '''
                If we have no evidence put all zero
                '''
                #pass
                for RG in RGs:
                    f.write("0\t")
                
                        
            f.write("%s\n"%tot)
            
def coverageSearch(input_bam, mRNA, mRNAedges):
    '''
    perform a pipleup inside each intron...
    '''
    def covList(mRNA, file):
        cov = [{} for x in range(mRNA.end - mRNA.start +1)]
        samfile = pysam.Samfile(file,"rb")
        for AlgnRead in samfile.fetch(mRNA.contig, mRNA.start, mRNA.end):
            read = ReadWrap(AlgnRead)
            for exon in read.exons:
                for pos in range(exon[0], exon[1]):
                    if pos >= mRNA.start and pos <= mRNA.end:
                        if read.RG in cov[pos - mRNA.start]:
                            cov[pos - mRNA.start][read.RG] += 1
                        else:
                            cov[pos - mRNA.start][read.RG] = 1
        samfile.close()
        return cov
    
    def covXmin(cov):
        c_min = -1
        posDiz_min = {}
        for posDiz in cov:
            c_sum = sum(posDiz.values())
            if c_min == -1:
                c_min = c_sum
                posDiz_min = posDiz
            elif c_sum < c_min:
                c_min = c_sum
                posDiz_min = posDiz
            else:
                pass
            if c_min == 0:
                break
        return posDiz_min
    
    def covXav(cov):
        c = 0.
        posDiz_av = dict.fromkeys(cov[0],0.)
        for posDiz in cov:
            c+=1
            for rg in posDiz:
                if rg in posDiz_av:
                    posDiz_av[rg] += posDiz[rg]
                else:
                    posDiz_av[rg] = posDiz[rg]
        for rg in posDiz_av:
            posDiz_av[rg] = posDiz_av[rg]/c
        return posDiz_av
    
    cov = covList(mRNA, input_bam)
    intronRetention_minVal = dict.fromkeys(mRNAedges,{})
    intronRetention_avVal = dict.fromkeys(mRNAedges,{})
    for edge in mRNAedges:
        cov_edge = cov[edge[0]-mRNA.start : edge[1]-mRNA.start]
        intronRetention_minVal[edge] = covXmin(cov_edge)
        intronRetention_avVal[edge] = covXav(cov_edge)
    return intronRetention_minVal, intronRetention_avVal

def evidenceCheck(site, dictionary, RGs):
    """
    return one of the follow category, based on reads count for <site> 
    in the <dictionary> and <RGs> 
    
    A: total 100+ reads and 5+ reads in 5+ RG
    B: total 100+ reads or 5+ reads in 5+ RG
    C: total 36+ reads and 3+ reads in 3+ RG
    D: total 36+ reads or 3+ reads in 3+ RG
    E: TRASH
    """
    tot = 0 # tot number of reads
    plus1 = 0 # number of RG with 1+ reads
    plus3 = 0 # number of RG with 1+ reads
    plus5 = 0 # number of RG with 1+ reads
    for RG in RGs:
        try:
            tot += dictionary[site][RG]
            if dictionary[site][RG] >= 1:
                plus1 += 1
            if dictionary[site][RG] >= 3:
                plus3 += 1
            if dictionary[site][RG] >= 5:
                plus5 += 1
        except KeyError:
            pass
    if tot >= 100 and plus5 >= 5:
        return "A"
    elif tot >= 50 or plus5 >= 5:
        return "B"
    elif tot >= 9 and plus3 >= 3:
        return "C"
    elif tot >= 3 or plus1 >= 3:
        return "D"
    else:
        return "E"


def main():
    print "[Module] findtools.AS"

if __name__ == '__main__':
    main()
